import { Component } from '@angular/core';

@Component({
    selector: 'listProduct',
    templateUrl: './list-product.component.html'
})

export class ListProductComponent {

    products: Product[];
    display() {
        this.products = [
            new Product(1, "Nokia 6600", 5000, 99),
            new Product(2, "Samsung Note", 35000, 99),
            new Product(3, "iPHONE XS", 50000, 99),
            new Product(4, "Mi 9", 5000, 99)
        ]
    }
}

export class Product { //not a component, just a normal helper class which we use to get products

    id: number;
    name: string;
    price: number;
    quantity: number;

    constructor(id: number, name: string, price: number, quantity: number) {
        this.name = name;
        this.id = id;
        this.price = price;
        this.quantity = quantity;
    }
}