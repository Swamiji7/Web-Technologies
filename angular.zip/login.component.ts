import { Component } from '@angular/core';

@Component({
    selector:'login',
    templateUrl:'./login.component.html'
})

export class LoginComponent{

    username:string;
    password:string;
    message:string;

    authenticate(){
        if(this.username=='majrul' && this.password=='123')
            this.message="Valid user";
        else
            this.message="Invalid username/Password";
    }

    
}
