import {Component} from "@angular/core";
import { NgIf } from '@angular/common';

@Component({
    selector:'luckyno',
    template:`
        
        <h1 *ngIf="luckyNumber">Your lucky number is  {{luckyNumber}}</h1>
        <button (click)="generate()">Click here to generate lucky number</button>

    `,
})

export class LuckyNoComponent{
    //luckyNumber:number = Math.ceil(Math.random()*10);
    luckyNumber:number;
    //message:String="Your lucky no is :";
        
    generate(){
        
        this.luckyNumber = Math.ceil(Math.random()*10);
               }

        
    }


