import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import{FormsModule} from '@angular/forms';
import { AppComponent } from './app.component';
import { HelloComponent } from 'src/app/hello.component';
import {LuckyNoComponent} from 'src/app/luckyno.component';
import {LoginComponent} from 'src/app/login.component';
import{CalComponent} from 'src/app/calculator.component';
import {ListProductComponent} from 'src/app/list-product.component';

@NgModule({
  declarations: [
    AppComponent,
    HelloComponent,
    LuckyNoComponent,
    LoginComponent,
    CalComponent,
    ListProductComponent
  ],
  imports: [
    BrowserModule,
    FormsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
