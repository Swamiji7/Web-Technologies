import { Component } from '@angular/core';

@Component({
    selector:'calculator',
    templateUrl:'./calculator.component.html'
})

export class CalComponent{

    
    number1:number;
    number2:number;
    number3:number;
    
    add(){
        this.number3=this.number1+this.number2;
        
    }

    subtract(){
        this.number3=this.number1-this.number2;
        
    }

    mul(){
        this.number3=this.number1*this.number2;
        
    }

    div(){
        this.number3=this.number1/this.number2;
        
    }
}
