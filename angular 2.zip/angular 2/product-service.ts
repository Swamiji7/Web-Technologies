import { Injectable } from '@angular/core';
import{Product} from 'src/app/product';

/*
classes which we write to code in Angular for communicating with the server
are commonly referred to as service classes
*/
@Injectable()

export class ProductService{

    fetchListOfProducts():Product[]{
        return [
            new Product(1, "Nokia 6600", 5000, 99, "nokia.jpg"),
            new Product(2, "Samsung Note", 35000, 99, "nokia.jpg"),
            new Product(3, "iPHONE XS", 50000, 99, "nokia.jpg"),
            new Product(4, "Mi 9", 5000, 99, "nokia.jpg")
        ];
    }
}