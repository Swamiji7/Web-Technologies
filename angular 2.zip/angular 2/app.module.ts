import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import {ListProductComponent} from 'src/app/list-product.component';
import{LoginComponent} from 'src/app/login.component';
import {FormsModule} from '@angular/forms';
import { AppComponent } from './app.component';
import { ProductService } from 'src/app/product-service';
import {RouterModule} from '@angular/router';
import {RegisterComponent} from 'src/app/register.component';

@NgModule({
  declarations: [
    AppComponent,
    ListProductComponent,
    LoginComponent,
    RegisterComponent
  ],
  imports: [
    BrowserModule,
    FormsModule,
    RouterModule.forRoot([
      {path:'login',component:LoginComponent},{path:'register',component:RegisterComponent},{path:'products',component:ListProductComponent}
    ])
  ],
  providers: [ProductService],
  bootstrap: [AppComponent]
})
export class AppModule { }
 