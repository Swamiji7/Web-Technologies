import { Component } from '@angular/core';


@Component({
  selector: 'app-root',
  template: `
    <!--The content below is only a placeholder and can be replaced.-->
    <div style="text-align:center">
    <img src="assets/flipkart.svg" width="300px" height="150px"/>  
    <h1>
        Welcome to Flipkart!
      </h1>
      <a [routerLink]="['/login']"><button style="border-radius:20px">Login</button></a><br/><br/>
      <a [routerLink]="['/register']"><button style="border-radius:20px">Register</button></a><br/><br/>
      <a [routerLink]="['/products']"><button style="border-radius:20px">Products for Sale</button></a>
    <br/><br/>
    <router-outlet></router-outlet>
  `,
  styles: []
})
export class AppComponent {
  title = 'app2';
}
