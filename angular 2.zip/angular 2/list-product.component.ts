import { Component } from '@angular/core';
import {Product} from 'src/app/product';
import {ProductService} from 'src/app/product-service';

@Component({
    selector: 'listProduct',
    templateUrl: './list-product.component.html',
    styleUrls: ['./list-product.component.css']
})

export class ListProductComponent {

    //dependency injection: objects are created automatically
    constructor(private ps:ProductService){ 
    
        //this is constructor injection
        //here we dont use 'new' keyword to create object, Angular automatically creates the object with the pointer ps
    }
    products:Product[];
    display(){
      
        //let ps:ProductService=new ProductService();
        this.products=this.ps.fetchListOfProducts();
    }
}
    


