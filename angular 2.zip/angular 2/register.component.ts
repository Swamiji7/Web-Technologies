import { Component } from '@angular/core';


@Component({
    selector:'register',
    template:`
        <form (ngSubmit)="register()">
            <label>Name :</label>
            <input name="name" [(ngModel)]=user.name /><br/>

            <label>Email :</label>
            <input name="email" [(ngModel)]=user.email/><br/>

            <label>Username :</label>
            <input name="username" [(ngModel)]=user.username/><br/>

            <label>Password :</label>
            <input name="password" [(ngModel)]=user.password/><br/>

            <button type="submit">Register</button>
        </form>
    `,
})
export class RegisterComponent{
    
    user:User=new User();
    register(){
        console.log(this.user);
    }

}

export class User{
    name:string;
    email:string;
    username:string;
    password:string;
  
}