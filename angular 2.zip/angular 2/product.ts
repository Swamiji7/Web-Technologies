export class Product { //not a component, just a normal helper class which we use to get products

    id: number;
    name: string;
    price: number;
    quantity: number;
    imageURL: string;

    constructor(id: number, name: string, price: number, quantity: number, imageURL: string) {
        this.name = name;
        this.id = id;
        this.price = price;
        this.quantity = quantity;
        this.imageURL = imageURL;
    }
}